package interfaces;

public interface ObservadorIF {

	void notify(ObservadoIF observado);

}
